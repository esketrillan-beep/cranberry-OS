# Cranberry OS — Build en la nube (GitHub Actions)

hecho por STWA

Esto te da una ISO REAL y booteable de Cranberry OS, compilada por los
servidores de GitHub (gratis). No necesitas instalar Linux en ningún
lado para construirla — solo subes esta carpeta a GitHub y esperas.

## Paso 1: Crea una cuenta de GitHub (si no tienes)
Ve a https://github.com y regístrate gratis.

## Paso 2: Crea un repositorio nuevo
1. Click en el botón "+" arriba a la derecha → "New repository".
2. Ponle un nombre, por ejemplo "cranberry-os".
3. Déjalo en "Public".
4. NO marques ninguna casilla de "Add README" ni nada más.
5. Click "Create repository".

## Paso 3: Sube estos archivos
1. En la página del repositorio recién creado, busca el link que dice
   "uploading an existing file" (o el botón "Add file" → "Upload files").
2. Arrastra TODA esta carpeta (o todos sus archivos y subcarpetas)
   a esa página. Asegúrate de que la carpeta ".github" se suba tal
   cual, con su estructura interna intacta.
3. Abajo, click "Commit changes".

## Paso 4: Ejecuta el build
1. Arriba en el repositorio, click en la pestaña "Actions".
2. Vas a ver "Build Cranberry OS ISO" en la lista de la izquierda,
   dale click.
3. Click en el botón "Run workflow" (a la derecha) → "Run workflow"
   de nuevo para confirmar.
4. Espera. Va a aparecer un círculo amarillo girando — eso significa
   que está compilando. Tarda entre 15 y 30 minutos. Puedes cerrar
   la página y volver después, no se cancela.

## Paso 5: Descarga tu ISO
1. Cuando el círculo se ponga verde con un check, click sobre ese
   resultado (el que dice "Build Cranberry OS ISO").
2. Abajo de todo vas a ver una sección "Artifacts" con un archivo
   llamado "cranberry-os-iso". Click ahí para descargarlo.
3. Eso descarga un .zip — descomprímelo y adentro está tu
   "cranberry-os.iso", real y lista para usar.

## Paso 6: Úsala en tu VM
Crea tu máquina virtual de prueba (VirtualBox, VMware, lo que uses),
y cuando te pida el disco de arranque / instalación, selecciona ese
"cranberry-os.iso". Va a bootear como un Linux real, mostrando tu
logo de Cranberry OS y tus mensajes personalizados.

## Si algo falla
Si el círculo se pone rojo (❌) en vez de verde, click en el build
fallido, fíjate en qué paso dice el error, y copia el mensaje —
mándamelo tal cual y te digo qué corregir.
